import os, tempfile, unittest
os.environ["ECOCOIN_DB_PATH"] = os.path.join(tempfile.gettempdir(), "ecocoin_test_suite.db")
import database

class EcoCoinDatabaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try: os.remove(os.environ["ECOCOIN_DB_PATH"])
        except FileNotFoundError: pass
        database.init_db()

    def test_admin_seeded(self):
        self.assertIsNotNone(database.authenticate("admin","ChangeMe_EcoCoin_2026!"))

    def test_users_get_separate_wallets(self):
        ok,_=database.create_user("Test One","test_one","strongpassword1")
        self.assertTrue(ok)
        u=database.authenticate("test_one","strongpassword1")
        before=database.get_wallet(u["id"])["balance"]
        database.submit_waste(u["id"],"Plastic",2,"test",20)
        pending=database.get_wallet(u["id"])["pending"]
        self.assertEqual(before,0)
        self.assertEqual(pending,20)

if __name__=="__main__": unittest.main()
